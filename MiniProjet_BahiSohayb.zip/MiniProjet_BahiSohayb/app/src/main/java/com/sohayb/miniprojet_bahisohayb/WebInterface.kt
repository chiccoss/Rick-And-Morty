package com.sohayb.miniprojet_bahisohayb

import kotlinx.coroutines.Deferred
import retrofit2.http.GET
import retrofit2.http.Path

interface WebInterface {

    @GET("users/{id}")
    suspend fun user(@Path("id") id: Long): Episode
}
