package com.sohayb.miniprojet_bahisohayb

import com.jakewharton.retrofit2.adapter.kotlin.coroutines.CoroutineCallAdapterFactory
import okhttp3.OkHttpClient
import retrofit2.CallAdapter
import retrofit2.CallAdapter.Factory
import retrofit2.Retrofit
import retrofit2.create
import kotlin.time.measureTime


class RetroFitDataSource  {

    private var retrofit: Retrofit
    private val BASE_URL = "https://rickandmortyapi.com/api/"


    init {
        val okHttpClient= OkHttpClient.Builder().build()
            retrofit = Retrofit.Builder()
                .baseUrl(BASE_URL)
                .addCallAdapterFactory(CoroutineCallAdapterFactory())
                .addConverterFactory(GsonConverterFactory.create())
                .client(okHttpClient)
                .build()


    }
    fun getInfoFromInterface(): RetroFitDataSource {
       return retrofit.create(RetroFitDataSource::class.java)
    }
}