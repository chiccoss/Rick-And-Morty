package com.sohayb.miniprojet_bahisohayb

data class Episode (
    val id: String,
    val name: String
)