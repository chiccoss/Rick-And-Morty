package com.sohayb.miniprojet_bahisohayb

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import kotlinx.android.synthetic.main.activity_main.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers.IO
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch

class MainActivity : AppCompatActivity() {

    val RESULT_ONE = "Result1"
    val RESULT_TWO = "Result2"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        var u=0
        button.setOnClickListener {
            // IO : NETWORK AND DB
            // MAIN FOR THINGS IN MAIN THREAD
            // DEFAULT FOR HEAVY OPERATIONS
            u++
            CoroutineScope(IO).launch { // or use GlobalScope
                ApiRequest ()
            }
        }
    }

    /*suspend*/ fun ApiRequest() {
        textView.text=getResult1FromAPI()
        textView.text=getRes2()
        println("debug :  ")

    }


    private /*suspend*/ fun getResult1FromAPI(): String {
        logT("getresult1FromAPI")
        //delay(1000)
        return RESULT_ONE
        //Thread.sleep(1000)
    }

     fun getRes2() : String{
        logT("getRes2")
        //delay(1000)
        return RESULT_TWO
    }

    fun logT(methodName: String) {
        println("debug : The method calling is $methodName")
    }
}
